# R/components/side_nav.R -------------------------------------------------
# Minimal "On this page" side navigation component.
#
# Some environments don't provide a `side_nav()` helper, but several pages
# in this dashboard call it. This implementation is dependency-light and
# works with the GOV.UK frontend classes already used across the app.

side_nav <- function(ns, sections, title = "On this page") {
  # `sections` is expected as a list like:
  # list(list(heading = "Section", items = c("Label" = "anchor-id", ...)), ...)
  
  build_section <- function(sec) {
    heading <- sec$heading %||% ""
    items <- sec$items %||% character(0)
    
    tags$div(
      class = "govuk-!-margin-bottom-4",
      if (nzchar(heading)) tags$h2(class = "govuk-heading-s govuk-!-margin-bottom-1", heading),
      tags$ul(
        class = "govuk-list govuk-!-margin-0",
        lapply(names(items), function(lbl) {
          anchor <- unname(items[[lbl]])
          tags$li(
            tags$a(
              class = "govuk-link",
              href = paste0("#", anchor),
              lbl
            )
          )
        })
      )
    )
  }
  
  # Render a compact "On this page" box above the page content.
  tags$div(
    class = "govuk-width-container",
    tags$div(
      class = "govuk-grid-row",
      tags$div(
        class = "govuk-grid-column-one-third",
        tags$aside(
          class = "govuk-!-margin-top-4 govuk-!-margin-bottom-4",
          tags$h2(class = "govuk-heading-m", title),
          lapply(sections, build_section)
        )
      )
    )
  )
}
