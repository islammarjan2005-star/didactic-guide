
# R/pages/page_employment.R

source("R/pages/labour_market_helpers.R")

library(ggplot2)
library(scales)
library(plotly)

# Map / DB deps (regional map)
library(DBI)
library(RPostgres)
library(dplyr)
library(leaflet)
library(sf)



#' Employment age group codes for levels and rates
#' @description Maps each age group to its ONS dataset codes
employment_age_codes <- data.frame(
  age_group = AGE_CHOICES,
  level_code = c("MGRZ", "LF2G", "YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"),
  rate_code  = c("MGSR", "LF24", "YBUA", "YBUD", "YBUG", "YBUJ", "LF2U", "LFK6"),
  stringsAsFactors = FALSE
)

#' Employment codes for stacked 
stacked_employment_codes <- data.frame(
  age_group = AGE_STACK,
  code = c("YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"),
  stringsAsFactors = FALSE
)



#' Employment Page UI
#'
#' Creates the full Employment page with multiple sections:
#' Overview, Employment by Age, Employment by Gender, Employment by Sector.
#'
#' @param id Character. The module namespace ID.
#' @return A Shiny tagList containing the complete page UI.
#' @export
employment_ui <- function(id) {
  ns <- NS(id)
  
  toc_sections <- list(
    list(
      heading = "Live Full Sample",
      items = c("Overview"           = "employment-overview",
                "Employment by Age"  = "employment-age")
    ),
    list(
      heading = "Full Sample Microdata",
      items = c("Employment by Gender" = "employment-gender",
                "Employment by Sector" = "employment-sector")
    )
  )
  
  tagList(
    side_nav(ns, sections = toc_sections, title = "On this page"),
    
    div(class = "govuk-width-container",
        tags$main(class = "govuk-main-wrapper",
                  tags$span(class = "govuk-caption-xl", "Labour Market"),
                  tags$h1(class = "govuk-heading-xl", "Employment"),
                  tags$p(class = "govuk-body-s", paste("Last updated:", Sys.Date())),
                  
                  #  Grid-
                  div(class = "govuk-grid-row",
                      div(class = "govuk-grid-column-full",
                          
                          tags$section(id = "employment-overview",
                                       div(class = "govuk-grid-row",
                                           uiOutput(ns("card_unemploy")),
                                           uiOutput(ns("card_duration")),
                                           uiOutput(ns("card_pop"))
                                       ),
                                       
                                       h2(class = "govuk-heading-m", "Trends over time"),
                                       
                                       sliderInput(ns("range"), "Year Range",
                                                   min(economics$date), max(economics$date),
                                                   value = c(as.Date("2010-01-01"), max(economics$date)),
                                                   width = "100%"),
                                       
                                       shinyWidgets::sliderTextInput(
                                         inputId = ns("lfs_date_range"),
                                         label   = "Select LFS Data Range",
                                         choices = rev(lfs_tables_full$yearquarter),
                                         selected = c("2020 Q1", lfs_tables_full$yearquarter[1]),
                                         grid = TRUE,
                                         width = "100%"
                                       ),
                                       
                                       uiOutput(ns("date_slider")),
                                       textOutput(ns("selection")),
                                       
                                       selectizeInput(
                                         inputId = ns("table_select"),
                                         label   = "Pick table from range to display:",
                                         choices = NULL,
                                         options = list(placeholder = "Type to search..."),
                                         width   = "100%"
                                       ),
                                       
                                       verbatimTextOutput(ns("picked_table")),
                                       textOutput(ns("lfs_list")),
                                       
                                       # Trend vis card
                                       mod_govuk_data_vis_card_ui(
                                         id = ns("trend_card"),
                                         title = "Employment trend",
                                         help_text = "This card hosts the visual only. Global and visual-specific filters live elsewhere.",
                                         visual_content = plotlyOutput(ns("trend"), height = "350px")
                                       ),

                                       tags$hr(class = "govuk-section-break govuk-section-break--m govuk-section-break--visible"),
                                       tags$h2(class = "govuk-heading-m", "Regional map"),
                                       tags$p(class = "govuk-body", "Interactive map of labour-market indicators by UK region and country."),

                                       div(class = "govuk-grid-row",
                                           div(class = "govuk-grid-column-one-third",
                                               selectInput(
                                                 inputId = ns("region_metric"),
                                                 label   = "Metric",
                                                 # Match the exact strings in ons.labour_market__regional_survey
                                                 choices = c("Economically active" = "Economically active 1",
                                                             "Employment" = "Employment",
                                                             "Unemployment" = "Unemployment",
                                                             "Economically inactive" = "Economically inactive"),
                                                 selected = "Employment",
                                                 width = "100%"
                                               ),
                                               selectInput(
                                                 inputId = ns("region_age"),
                                                 label   = "Age group",
                                                 choices = c("Aged 16+" = "Aged 16+",
                                                             "Aged 16-64" = "Aged 16-64"),
                                                 selected = "Aged 16-64",
                                                 width = "100%"
                                               ),
                                               selectInput(
                                                 inputId = ns("region_value_type"),
                                                 label   = "Value type",
                                                 # Data Explorer shows rate footnotes (e.g., "Rate (%)2", "Rate (%)3")
                                                 choices = c("Rate (activity/employment/inactivity)" = "Rate (%)2",
                                                             "Rate (unemployment)" = "Rate (%)3",
                                                             "Level" = "Level"),
                                                 selected = "Rate (%)2",
                                                 width = "100%"
                                               )
                                           ),
                                           div(class = "govuk-grid-column-two-thirds",
                                               mod_govuk_data_vis_card_ui(
                                                 id = ns("regional_map_card"),
                                                 title = "Regional indicator map",
                                                 help_text = "Hover for values. Colours show relative magnitude across regions.",
                                                 visual_content = leafletOutput(ns("regional_map"), height = "450px")
                                               )
                                           )
                                       )
                          ),
                          
                          tags$section(id = "employment-age",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Age"),
                                       
                                       # Employment by Age 
                                       labour_metric_ui(
                                         id = ns("age_card"),
                                         title = "Employment",
                                         level_colour = "#1d70b8",
                                         rate_colour = "#00703c"
                                       )
                          ),
                          
                          tags$section(id = "employment-gender",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Gender"),
                                       textAreaInput(ns("notes_gender"), label = NULL, value = "",
                                                     placeholder = strrep("This is a very long placeholder. ", 200))
                          ),
                          
                          tags$section(id = "employment-sector",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Sector"),
                                       textAreaInput(ns("notes_sector"), label = NULL, value = "",
                                                     placeholder = strrep("This is a very long placeholder. ", 200))
                          )
                      )
                  )
        )
    )
  )
}




#' Employment Page Server
#'
#' Server logic for the Employment page. Handles data fetching, filtering,
#' and wiring up the various visualization modules.
#'
#' @param id Character. The module namespace ID.
#' @export
employment_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    mod_govuk_data_vis_card_server("trend_card")
    mod_govuk_data_vis_card_server("regional_map_card")

    # --- Regional map data (ONS regional survey) ---
    # Area codes used in the Excel screenshot: English regions + devolved nations.
    region_lookup <- tibble::tribble(
      ~area_code,   ~area_name,
      "E12000001",  "North East",
      "E12000002",  "North West",
      "E12000003",  "Yorkshire and The Humber",
      "E12000004",  "East Midlands",
      "E12000005",  "West Midlands",
      "E12000006",  "East",
      "E12000007",  "London",
      "E12000008",  "South East",
      "E12000009",  "South West",
      "W92000004",  "Wales",
      "S92000003",  "Scotland",
      "N92000002",  "Northern Ireland"
    )

    # NOTE: In many corporate environments external map tiles (Carto/OSM/etc.) are blocked.
    # Also, region boundary packages may not be installed. To make the map ALWAYS render,
    # we use fixed centroids for each ITL1 region / devolved nation and plot POINTS.
    # (This matches your requirement: "UK map, with points situated" and click for values.)
    region_points <- tibble::tribble(
      ~area_code,  ~lat,    ~lng,
      "E12000001", 54.95,  -1.60,   # North East (Newcastle)
      "E12000002", 53.80,  -2.30,   # North West (Manchester)
      "E12000003", 53.80,  -1.50,   # Yorkshire and The Humber (Leeds)
      "E12000004", 52.95,  -1.15,   # East Midlands (Nottingham)
      "E12000005", 52.48,  -1.90,   # West Midlands (Birmingham)
      "E12000006", 52.24,   0.72,   # East (Cambridge)
      "E12000007", 51.51,  -0.12,   # London
      "E12000008", 51.45,  -0.97,   # South East (Reading)
      "E12000009", 50.72,  -3.53,   # South West (Exeter)
      "W92000004", 51.48,  -3.18,   # Wales (Cardiff)
      "S92000003", 55.95,  -3.19,   # Scotland (Edinburgh)
      "N92000002", 54.60,  -5.93    # Northern Ireland (Belfast)
    )

    # DB connection for regional survey table
    conn_regional <- dbConnect(RPostgres::Postgres())
    onStop(function() {
      try(dbDisconnect(conn_regional), silent = TRUE)
    })

    regional_survey <- reactive({
      req(input$region_metric, input$region_age, input$region_value_type)

      codes_sql <- paste0("'", region_lookup$area_code, "'", collapse = ",")
      q <- sprintf(
        'SELECT employment_group, age_group, value_type, area_code, value\n         FROM "ons"."labour_market__regional_survey"\n         WHERE area_code IN (%s)\n           AND employment_group = %s\n           AND age_group = %s\n           AND value_type = %s',
        codes_sql,
        dbQuoteString(conn_regional, input$region_metric),
        dbQuoteString(conn_regional, input$region_age),
        dbQuoteString(conn_regional, input$region_value_type)
      )

      df <- dbGetQuery(conn_regional, q)
      df$value <- as.numeric(df$value)
      df <- dplyr::left_join(df, region_lookup, by = "area_code")
      df
    })

    output$regional_map <- renderLeaflet({
      dat <- regional_survey()
      req(nrow(dat) > 0)

      map_df <- region_points |>
        dplyr::left_join(dat, by = "area_code") |>
        dplyr::left_join(region_lookup, by = "area_code")

      # Colour palette (based on values)
      rng <- range(map_df$value, na.rm = TRUE)
      pal <- leaflet::colorNumeric(palette = "YlOrRd", domain = rng, na.color = "#b1b4b6")

      fmt_value <- function(x) {
        if (grepl("^Rate", input$region_value_type %||% "")) {
          paste0(sprintf("%.1f", x), "%")
        } else {
          scales::comma(round(x))
        }
      }

      popup <- sprintf(
        "<strong>%s</strong><br/>%s<br/><span style='font-size:12px;'>%s • %s • %s</span>",
        map_df$area_name %||% map_df$area_code,
        ifelse(is.na(map_df$value), "No data", fmt_value(map_df$value)),
        input$region_metric,
        input$region_age,
        input$region_value_type
      ) |>
        lapply(htmltools::HTML)

      # NOTE: In DBT/secure environments, external leaflet tile servers (OSM/Carto/etc.) are
      # often blocked. So we avoid addTiles() and instead draw a lightweight UK outline locally
      # (if the `maps` package is available), then overlay clickable points.

      m <- leaflet(map_df, options = leafletOptions(zoomControl = TRUE, minZoom = 4))

      # Base outline (no web tiles, no internet): a lightweight, hard-coded UK outline.
# This avoids reliance on external tile servers and avoids needing packages that ship boundary data.
# Coordinates are a coarse outline just to give geographic context behind the points.
uk_gb <- matrix(c(
  -6.5, 49.9,
  -5.5, 50.1,
  -4.8, 50.3,
  -3.7, 50.4,
  -2.5, 50.6,
  -1.2, 50.8,
   0.3, 50.9,
   1.5, 51.0,
   1.8, 52.0,
   1.2, 53.0,
   0.6, 54.2,
  -0.5, 55.0,
  -1.8, 55.7,
  -3.0, 56.3,
  -4.5, 57.0,
  -5.7, 58.0,
  -6.0, 58.6,
  -5.2, 58.8,
  -4.0, 58.5,
  -3.0, 57.8,
  -2.2, 57.0,
  -1.7, 56.2,
  -2.0, 55.5,
  -3.0, 54.9,
  -3.7, 54.5,
  -4.5, 54.0,
  -5.2, 53.2,
  -5.6, 52.5,
  -5.8, 51.8,
  -6.1, 51.2,
  -6.5, 50.6,
  -6.5, 49.9
), ncol = 2, byrow = TRUE)

uk_ni <- matrix(c(
  -8.2, 54.0,
  -7.8, 54.1,
  -7.2, 54.3,
  -6.2, 54.6,
  -5.6, 54.9,
  -5.6, 55.3,
  -6.2, 55.4,
  -7.0, 55.2,
  -7.6, 54.9,
  -8.1, 54.5,
  -8.2, 54.0
), ncol = 2, byrow = TRUE)

uk_outline <- sf::st_sf(
  name = c("Great Britain", "Northern Ireland"),
  geometry = sf::st_sfc(
    sf::st_polygon(list(uk_gb)),
    sf::st_polygon(list(uk_ni)),
    crs = 4326
  )
)

m <- m |>
  addPolygons(
    data = uk_outline,
    fill = FALSE,
    color = "#505a5f",
    weight = 1,
    opacity = 1
  )

      m |>
        addCircleMarkers(
          lng = ~lng,
          lat = ~lat,
          radius = 10,
          stroke = TRUE,
          weight = 1,
          opacity = 0.9,
          color = "#0b0c0c",
          fillOpacity = 0.85,
          fillColor = ~pal(value),
          popup = popup
        ) |>
        fitBounds(lng1 = -8.5, lat1 = 49.5, lng2 = 2.5, lat2 = 59.5) |>
        addLegend(
          pal = pal,
          values = ~value,
          opacity = 0.85,
          title = paste(input$region_metric, "-", input$region_age, "(", input$region_value_type, ")"),
          position = "bottomright"
        )
    })
    
    dat <- reactive({
      economics[economics$date >= input$range[1] & economics$date <= input$range[2], ]
    })
    
    output$selection <- renderText({
      paste("Selected range:",
            input$lfs_date_range[1], "to",
            input$lfs_date_range[2])
    })
    
    lfs_selected_tables <- reactive({
      get_lfs_table_from_range(input$lfs_date_range[1], input$lfs_date_range[2])
    })
    
    output$lfs_list <- renderText({
      paste("Selected LFS tables: ",
            paste(lfs_selected_tables(), collapse = ", "))
    })
    
    observeEvent(lfs_selected_tables(), {
      choices <- lfs_selected_tables()
      req(length(choices) > 0)
      
      current <- isolate(input$table_select)
      selected <- if (!is.null(current) && current %in% choices) current else choices[1]
      
      updateSelectizeInput(
        session  = session,
        inputId  = "table_select",
        choices  = choices,
        selected = selected,
        server   = TRUE
      )
    }, ignoreInit = FALSE)
    
    output$picked_table <- renderPrint({
      input$table_select
    })
    
    
    #  Stats Cards
    
    output$card_unemploy <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$unemploy, 1); prev <- tail(d$unemploy, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("unemploy"),
        title    = "Total Unemployed",
        headline = govuk_format_number(curr),
        delta    = govuk_format_number(delta),
        period   = "vs last month",
        good_if_increase = FALSE
      )
    })
    
    output$card_duration <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$uempmed, 1); prev <- tail(d$uempmed, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("duration"),
        title    = "Duration (Weeks)",
        headline = govuk_format_number(curr),
        delta    = scales::comma(round(delta, 1)),
        period   = "vs last month",
        good_if_increase = FALSE
      )
    })
    
    output$card_pop <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$pop, 1); prev <- tail(d$pop, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("population"),
        title    = "Population",
        headline = govuk_format_number(curr),
        delta    = scales::comma(round(delta, 1)),
        period   = "vs last month",
        good_if_increase = TRUE
      )
    })
    
    # Trend plot
    output$trend <- renderPlotly({
      ggplotly(
        ggplot(dat(), aes(date, unemploy)) +
          geom_area(fill = "#cf102d", alpha = 0.2) +
          geom_line(col = "#cf102d", size = 1) +
          theme_minimal() +
          labs(x = NULL, y = "Unemployed (000s)")
      )
    })
    
    

    # Employment by Age 

        labour_metric_server(
      id = "age_card",
      title = "Employment",
      age_codes = employment_age_codes,
      stacked_codes = stacked_employment_codes,
      level_colour = "#1d70b8",
      rate_colour = "#00703c",
      invert = FALSE
    )
    
  })
}