# R/pages/page_map.R -----------------------------------------------------------
# Standalone regional map page (offline-friendly) using ggplot2 + maps + plotly.

map_ui <- function(id) {
  ns <- NS(id)

  div(
    class = "govuk-width-container",
    tags$main(
      class = "govuk-main-wrapper",

      tags$span(class = "govuk-caption-xl", "Labour Market"),
      tags$h1(class = "govuk-heading-xl", "Regional indicator map"),
      tags$p(class = "govuk-body-s", paste("Snapshot:", "Sep–Nov 2025 (published 20 Jan 2026)")),

      div(
        class = "govuk-grid-row",
        div(
          class = "govuk-grid-column-one-third",
          div(
            class = "govuk-form-group",
            tags$label(class = "govuk-label", `for` = ns("metric"), "Metric"),
            selectInput(
              ns("metric"),
              label = NULL,
              selected = "emp_rate",
              choices = c(
                "Employment rate (16–64)" = "emp_rate",
                "Unemployment rate (16+)" = "unemp_rate",
                "Economic activity rate (16–64)" = "ea_rate",
                "Economic inactivity rate (16–64)" = "inact_rate",
                "Employment level (16+)" = "emp_level",
                "Unemployment level (16+)" = "unemp_level",
                "Economically active level (16+)" = "ea_level",
                "Economically inactive level (16–64)" = "inact_level"
              ),
              width = "100%"
            )
          )
        ),
        div(
          class = "govuk-grid-column-two-thirds",
          tags$p(class = "govuk-body", "Click a point to view the full regional snapshot.")
        )
      ),

      div(
        style = "border: 2px solid #b1b4b6;",
        plotlyOutput(ns("uk_map"), height = "600px")
      )
    )
  )
}

map_server <- function(id) {
  moduleServer(id, function(input, output, session) {

    # Hardcoded snapshot from the provided Excel screenshot (Table 22).
    # Units: levels are in thousands.
    regions <- tibble::tibble(
      area_code = c(
        "E12000001","E12000002","E12000003","E12000004","E12000005",
        "E12000006","E12000007","E12000008","E12000009",
        "W92000004","S92000003","N92000002"
      ),
      area_name = c(
        "North East","North West","Yorkshire and The Humber","East Midlands","West Midlands",
        "East","London","South East","South West",
        "Wales","Scotland","Northern Ireland"
      ),
      ea_level = c(1318, 3934, 2883, 2635, 3136, 3511, 5232, 5154, 3092, 1550, 2783, 916),
      ea_rate  = c(74.0, 77.7, 77.5, 79.9, 78.5, 82.2, 79.7, 82.2, 81.6, 75.5, 77.7, 73.6),
      emp_level = c(1236, 3737, 2719, 2478, 2953, 3359, 4856, 4942, 2982, 1466, 2680, 896),
      emp_rate  = c(69.2, 73.8, 73.0, 75.0, 73.7, 78.5, 74.0, 78.8, 78.7, 71.3, 74.7, 72.0),
      unemp_level = c(82, 197, 164, 157, 184, 153, 376, 212, 110, 84, 103, 19),
      unemp_rate  = c(6.2, 5.0, 5.7, 6.0, 5.9, 4.3, 7.2, 4.1, 3.6, 5.4, 3.7, 2.1),
      inact_level = c(442, 1075, 799, 632, 820, 717, 1274, 1052, 656, 479, 760, 314),
      inact_rate  = c(26.0, 22.3, 22.5, 20.1, 21.5, 17.8, 20.3, 17.8, 18.4, 24.5, 22.3, 26.4)
    )

    # Approximate regional centroids for plotting points.
    # (Good enough for a demo map; replace with official centroids later.)
    coords <- tibble::tibble(
      area_name = c(
        "North East","North West","Yorkshire and The Humber","East Midlands","West Midlands",
        "East","London","South East","South West","Wales","Scotland","Northern Ireland"
      ),
      lat = c(54.97, 53.48, 53.80, 52.90, 52.48, 52.25, 51.51, 51.20, 50.70, 52.13, 56.49, 54.79),
      lng = c(-1.62, -2.25, -1.50, -0.90, -1.89, 0.45, -0.13, -0.80, -3.50, -3.78, -4.20, -6.49)
    )

    # UK outline (works offline). Note: map_data() is provided by ggplot2 (it
    # uses the 'maps' package under the hood). Some environments block
    # maps::map_data(), so call ggplot2::map_data() explicitly.
    uk_shape <- ggplot2::map_data("world", region = "UK")

    map_df <- reactive({
      dplyr::left_join(regions, coords, by = "area_name")
    })

    metric_meta <- list(
      emp_rate   = list(label = "Employment rate (16–64)", fmt = function(x) paste0(round(x, 1), "%")),
      unemp_rate = list(label = "Unemployment rate (16+)", fmt = function(x) paste0(round(x, 1), "%")),
      ea_rate    = list(label = "Economic activity rate (16–64)", fmt = function(x) paste0(round(x, 1), "%")),
      inact_rate = list(label = "Economic inactivity rate (16–64)", fmt = function(x) paste0(round(x, 1), "%")),
      emp_level  = list(label = "Employment level (16+)", fmt = function(x) paste0(scales::comma(x), "k")),
      unemp_level= list(label = "Unemployment level (16+)", fmt = function(x) paste0(scales::comma(x), "k")),
      ea_level   = list(label = "Economically active level (16+)", fmt = function(x) paste0(scales::comma(x), "k")),
      inact_level= list(label = "Economically inactive level (16–64)", fmt = function(x) paste0(scales::comma(x), "k"))
    )

    output$uk_map <- renderPlotly({
      df <- map_df()
      m <- metric_meta[[input$metric]]
      val <- df[[input$metric]]

      # Tooltip and click payload
      df$tooltip <- paste0(
        "<b>", df$area_name, "</b><br>",
        m$label, ": ", m$fmt(val)
      )

      p <- ggplot2::ggplot() +
        ggplot2::geom_polygon(
          data = uk_shape,
          ggplot2::aes(x = long, y = lat, group = group),
          fill = "#d2d2d2",
          color = "white",
          linewidth = 0.3
        ) +
        ggplot2::geom_point(
          data = df,
          ggplot2::aes(
            x = lng,
            y = lat,
            text = tooltip,
            customdata = area_name,
            color = !!rlang::sym(input$metric)
          ),
          size = 5
        ) +
        ggplot2::coord_fixed(1.3) +
        ggplot2::theme_void() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "#f3f2f1", color = NA)
        )

      plt <- plotly::ggplotly(p, tooltip = "text", source = "ukmap_click")
      plotly::layout(plt, margin = list(l = 0, r = 0, t = 0, b = 0))
    })

    observeEvent(plotly::event_data("plotly_click", source = "ukmap_click"), {
      click_info <- plotly::event_data("plotly_click", source = "ukmap_click")
      clicked_region <- click_info$customdata

      if (is.null(clicked_region)) return()

      row <- dplyr::filter(map_df(), area_name == clicked_region)
      if (nrow(row) != 1) return()

      # Nicer modal card (no area code, no source label)
      showModal(modalDialog(
        title = clicked_region,
        size = "m",
        easyClose = TRUE,
        footer = modalButton("Close"),
        HTML(paste0(
          "<div style='display:grid;grid-template-columns:1fr 1fr;gap:12px;'>",
          card("Employment rate (16–64)", paste0(row$emp_rate, "%"), "#1d70b8"),
          card("Unemployment rate (16+)", paste0(row$unemp_rate, "%"), "#d4351c"),
          card("Economic activity rate (16–64)", paste0(row$ea_rate, "%"), "#00703c"),
          card("Economic inactivity rate (16–64)", paste0(row$inact_rate, "%"), "#6f777b"),
          card("Employment level (16+)", paste0(scales::comma(row$emp_level), "k"), "#1d70b8"),
          card("Unemployment level (16+)", paste0(scales::comma(row$unemp_level), "k"), "#d4351c"),
          "</div>"
        ))
      ))
    })

    # small HTML helper
    card <- function(label, value, accent) {
      paste0(
        "<div style='border:1px solid #b1b4b6;border-left:6px solid ", accent,
        ";padding:12px;background:#ffffff;border-radius:6px;'>",
        "<div style='font-size:14px;color:#505a5f;margin-bottom:4px;'>", label, "</div>",
        "<div style='font-size:26px;font-weight:700;color:#0b0c0c;'>", value, "</div>",
        "</div>"
      )
    }

  })
}
