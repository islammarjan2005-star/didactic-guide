# dashboard/R/components/side_nav.R
# -------------------------------------------------------------------
# Minimal side navigation helper used by page modules.
#
# Some page modules call `side_nav(ns, sections, title)`.
# This repo previously did not define it, which caused:
#   could not find function "side_nav"
#
# This implementation renders a simple GOV.UK-style sidebar with anchor
# links to section IDs on the current page.

side_nav <- function(ns, sections, title = "On this page") {
  # ns: a namespace function from NS(id) (kept for compatibility)
  # sections: list(list(heading=..., items=c("Label"="anchor-id", ...)), ...)

  link_blocks <- lapply(sections, function(sec) {
    heading <- sec$heading %||% ""
    items <- sec$items %||% character(0)

    tags$div(
      class = "govuk-!-margin-bottom-4",
      if (nzchar(heading)) tags$h2(class = "govuk-heading-s govuk-!-margin-bottom-2", heading),
      tags$ul(
        class = "govuk-list govuk-!-margin-bottom-0",
        lapply(names(items), function(lbl) {
          tags$li(
            tags$a(
              class = "govuk-link",
              href = paste0("#", items[[lbl]]),
              lbl
            )
          )
        })
      )
    )
  })

  # A lightweight sidebar nav block. Pages can place this wherever they like.
  tags$aside(
    class = "govuk-!-margin-bottom-6",
    `aria-label` = title,
    tags$h2(class = "govuk-heading-m", title),
    link_blocks
  )
}
