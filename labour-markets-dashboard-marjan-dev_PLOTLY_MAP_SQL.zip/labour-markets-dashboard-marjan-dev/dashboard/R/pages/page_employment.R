
# R/pages/page_employment.R

source("R/pages/labour_market_helpers.R")

library(ggplot2)
library(scales)
library(plotly)
library(maps)



#' Employment age group codes for levels and rates
#' @description Maps each age group to its ONS dataset codes
employment_age_codes <- data.frame(
  age_group = AGE_CHOICES,
  level_code = c("MGRZ", "LF2G", "YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"),
  rate_code  = c("MGSR", "LF24", "YBUA", "YBUD", "YBUG", "YBUJ", "LF2U", "LFK6"),
  stringsAsFactors = FALSE
)

#' Employment codes for stacked 
stacked_employment_codes <- data.frame(
  age_group = AGE_STACK,
  code = c("YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"),
  stringsAsFactors = FALSE
)



#' Employment Page UI
#'
#' Creates the full Employment page with multiple sections:
#' Overview, Employment by Age, Employment by Gender, Employment by Sector.
#'
#' @param id Character. The module namespace ID.
#' @return A Shiny tagList containing the complete page UI.
#' @export
employment_ui <- function(id) {
  ns <- NS(id)
  
  toc_sections <- list(
    list(
      heading = "Live Full Sample",
      items = c("Overview"           = "employment-overview",
                "Employment by Age"  = "employment-age")
    ),
    list(
      heading = "Full Sample Microdata",
      items = c("Employment by Gender" = "employment-gender",
                "Employment by Sector" = "employment-sector")
    )
  )
  
  tagList(
    side_nav(ns, sections = toc_sections, title = "On this page"),
    
    div(class = "govuk-width-container",
        tags$main(class = "govuk-main-wrapper",
                  tags$span(class = "govuk-caption-xl", "Labour Market"),
                  tags$h1(class = "govuk-heading-xl", "Employment"),
                  tags$p(class = "govuk-body-s", paste("Last updated:", Sys.Date())),
                  
                  #  Grid-
                  div(class = "govuk-grid-row",
                      div(class = "govuk-grid-column-full",
                          
                          tags$section(id = "employment-overview",
                                       div(class = "govuk-grid-row",
                                           uiOutput(ns("card_unemploy")),
                                           uiOutput(ns("card_duration")),
                                           uiOutput(ns("card_pop"))
                                       ),
                                       
                                       h2(class = "govuk-heading-m", "Trends over time"),
                                       
                                       sliderInput(ns("range"), "Year Range",
                                                   min(economics$date), max(economics$date),
                                                   value = c(as.Date("2010-01-01"), max(economics$date)),
                                                   width = "100%"),
                                       
                                       shinyWidgets::sliderTextInput(
                                         inputId = ns("lfs_date_range"),
                                         label   = "Select LFS Data Range",
                                         choices = rev(lfs_tables_full$yearquarter),
                                         selected = c("2020 Q1", lfs_tables_full$yearquarter[1]),
                                         grid = TRUE,
                                         width = "100%"
                                       ),
                                       
                                       uiOutput(ns("date_slider")),
                                       textOutput(ns("selection")),
                                       
                                       selectizeInput(
                                         inputId = ns("table_select"),
                                         label   = "Pick table from range to display:",
                                         choices = NULL,
                                         options = list(placeholder = "Type to search..."),
                                         width   = "100%"
                                       ),
                                       
                                       verbatimTextOutput(ns("picked_table")),
                                       textOutput(ns("lfs_list")),
                                       
                                       # Trend vis card
                                       mod_govuk_data_vis_card_ui(
                                         id = ns("trend_card"),
                                         title = "Employment trend",
                                         help_text = "This card hosts the visual only. Global and visual-specific filters live elsewhere.",
                                         visual_content = plotlyOutput(ns("trend"), height = "350px")
                                       ),

                                       tags$hr(class = "govuk-section-break govuk-section-break--l govuk-section-break--visible"),
                                       h2(class = "govuk-heading-m", "Regional breakdown (UK map)"),
                                       p(class = "govuk-body", "Click a dot to see the latest value for that region."),

                                       div(class = "govuk-grid-row",
                                           div(class = "govuk-grid-column-one-third",
                                               selectInput(
                                                 inputId = ns("region_employment_group"),
                                                 label = "Group",
                                                 choices = c("Employment", "Unemployment", "Economically active 1", "Economically inactive"),
                                                 selected = "Employment",
                                                 width = "100%"
                                               )
                                           ),
                                           div(class = "govuk-grid-column-one-third",
                                               selectInput(
                                                 inputId = ns("region_age_group"),
                                                 label = "Age",
                                                 choices = c("Aged 16+", "Aged 16-64"),
                                                 selected = "Aged 16+",
                                                 width = "100%"
                                               )
                                           ),
                                           div(class = "govuk-grid-column-one-third",
                                               selectInput(
                                                 inputId = ns("region_value_type"),
                                                 label = "Measure",
                                                 choices = c("Level", "Rate (%)2", "Rate (%)3"),
                                                 selected = "Rate (%)2",
                                                 width = "100%"
                                               )
                                           )
                                       ),

                                       plotlyOutput(ns("uk_map"), height = "600px")
                                       )
                          ),
                          
                          tags$section(id = "employment-age",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Age"),
                                       
                                       # Employment by Age 
                                       labour_metric_ui(
                                         id = ns("age_card"),
                                         title = "Employment",
                                         level_colour = "#1d70b8",
                                         rate_colour = "#00703c"
                                       )
                          ),
                          
                          tags$section(id = "employment-gender",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Gender"),
                                       textAreaInput(ns("notes_gender"), label = NULL, value = "",
                                                     placeholder = strrep("This is a very long placeholder. ", 200))
                          ),
                          
                          tags$section(id = "employment-sector",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Sector"),
                                       textAreaInput(ns("notes_sector"), label = NULL, value = "",
                                                     placeholder = strrep("This is a very long placeholder. ", 200))
                          )
                      )
                  )
        )
    )
  )
}




#' Employment Page Server
#'
#' Server logic for the Employment page. Handles data fetching, filtering,
#' and wiring up the various visualization modules.
#'
#' @param id Character. The module namespace ID.
#' @export
employment_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    mod_govuk_data_vis_card_server("trend_card")
    
    dat <- reactive({
      economics[economics$date >= input$range[1] & economics$date <= input$range[2], ]
    })
    
    output$selection <- renderText({
      paste("Selected range:",
            input$lfs_date_range[1], "to",
            input$lfs_date_range[2])
    })
    
    lfs_selected_tables <- reactive({
      get_lfs_table_from_range(input$lfs_date_range[1], input$lfs_date_range[2])
    })
    
    output$lfs_list <- renderText({
      paste("Selected LFS tables: ",
            paste(lfs_selected_tables(), collapse = ", "))
    })
    
    observeEvent(lfs_selected_tables(), {
      choices <- lfs_selected_tables()
      req(length(choices) > 0)
      
      current <- isolate(input$table_select)
      selected <- if (!is.null(current) && current %in% choices) current else choices[1]
      
      updateSelectizeInput(
        session  = session,
        inputId  = "table_select",
        choices  = choices,
        selected = selected,
        server   = TRUE
      )
    }, ignoreInit = FALSE)
    
    output$picked_table <- renderPrint({
      input$table_select
    })
    
    
    #  Stats Cards
    
    output$card_unemploy <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$unemploy, 1); prev <- tail(d$unemploy, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("unemploy"),
        title    = "Total Unemployed",
        headline = govuk_format_number(curr),
        delta    = govuk_format_number(delta),
        period   = "vs last month",
        good_if_increase = FALSE
      )
    })
    
    output$card_duration <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$uempmed, 1); prev <- tail(d$uempmed, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("duration"),
        title    = "Duration (Weeks)",
        headline = govuk_format_number(curr),
        delta    = scales::comma(round(delta, 1)),
        period   = "vs last month",
        good_if_increase = FALSE
      )
    })
    
    output$card_pop <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$pop, 1); prev <- tail(d$pop, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("population"),
        title    = "Population",
        headline = govuk_format_number(curr),
        delta    = scales::comma(round(delta, 1)),
        period   = "vs last month",
        good_if_increase = TRUE
      )
    })
    
    # Trend plot
    output$trend <- renderPlotly({
      ggplotly(
        ggplot(dat(), aes(date, unemploy)) +
          geom_area(fill = "#cf102d", alpha = 0.2) +
          geom_line(col = "#cf102d", size = 1) +
          theme_minimal() +
          labs(x = NULL, y = "Unemployed (000s)")
      )
    })

    # ------------------------------------------------------------------------
    # Regional breakdown map (UK) - uses the same "maps" + ggplotly pattern as
    # your old working version, but swaps the fake stats for SQL values.
    # ------------------------------------------------------------------------

    conn_regions <- dbConnect(RPostgres::Postgres())
    onStop(function() {
      try(DBI::dbDisconnect(conn_regions), silent = TRUE)
    })

    # UK shape (offline)
    uk_shape <- map_data("world", region = "UK")

    # Region dots + codes (matches your Excel list)
    region_dots <- data.frame(
      area_code = c(
        "E12000001", "E12000002", "E12000003", "E12000004", "E12000005",
        "E12000006", "E12000007", "E12000008", "E12000009",
        "W92000004", "S92000003", "N92000002"
      ),
      name = c(
        "North East", "North West", "Yorkshire and The Humber", "East Midlands", "West Midlands",
        "East of England", "London", "South East", "South West",
        "Wales", "Scotland", "Northern Ireland"
      ),
      # Approximate regional centroids (good enough for clickable dots)
      lat = c(54.7, 53.8, 53.9, 52.9, 52.5, 52.2, 51.5, 51.2, 50.8, 52.2, 56.5, 54.7),
      lng = c(-1.6, -2.7, -1.3, -0.9, -2.0, 0.5, -0.1, -0.9, -3.6, -3.8, -4.2, -6.6),
      stringsAsFactors = FALSE
    )

    regional_values <- reactive({
      req(input$region_employment_group, input$region_age_group, input$region_value_type)

      codes_sql <- paste(sprintf("'%s'", region_dots$area_code), collapse = ",")

      # Build a shared condition string (no WHERE keyword)
      cond <- paste0(
        "area_code IN (", codes_sql, ") ",
        "AND employment_group = ", DBI::dbQuoteString(conn_regions, input$region_employment_group), " ",
        "AND age_group = ", DBI::dbQuoteString(conn_regions, input$region_age_group), " ",
        "AND value_type = ", DBI::dbQuoteString(conn_regions, input$region_value_type)
      )

      # Try latest-period query first (if time_period exists)
      q_latest <- paste0(
        'SELECT area_code, value, time_period\n',
        'FROM "ons"."labour_market__regional_survey"\n',
        'WHERE ', cond, '\n',
        'AND time_period = (\n',
        '  SELECT MAX(time_period)\n',
        '  FROM "ons"."labour_market__regional_survey"\n',
        '  WHERE ', cond, '\n',
        ')'
      )

      df <- tryCatch(
        DBI::dbGetQuery(conn_regions, q_latest),
        error = function(e) NULL
      )

      # Fallback: snapshot table (no time_period)
      if (is.null(df) || nrow(df) == 0) {
        q_snap <- paste0(
          'SELECT area_code, value\n',
          'FROM "ons"."labour_market__regional_survey"\n',
          'WHERE ', cond
        )
        df <- DBI::dbGetQuery(conn_regions, q_snap)
        df$time_period <- NA_character_
      }

      df$value <- as.numeric(df$value)
      df
    })

    output$uk_map <- renderPlotly({
      vals <- regional_values()

      dots_plot <- region_dots
      dots_plot <- merge(dots_plot, vals, by = "area_code", all.x = TRUE)

      # Tooltip text
      dots_plot$text <- ifelse(
        is.na(dots_plot$value),
        paste0(dots_plot$name, "<br>No data"),
        paste0(
          dots_plot$name,
          "<br>", input$region_employment_group,
          " | ", input$region_age_group,
          " | ", input$region_value_type,
          ifelse(!is.na(dots_plot$time_period), paste0("<br>", dots_plot$time_period), ""),
          "<br><b>", format(round(dots_plot$value, 2), nsmall = 2), "</b>"
        )
      )

      p <- ggplot() +
        geom_polygon(
          data = uk_shape,
          aes(x = long, y = lat, group = group),
          fill = "#d2d2d2",
          color = "white"
        ) +
        geom_point(
          data = dots_plot,
          aes(x = lng, y = lat, text = text, customdata = area_code),
          color = "#d4351c",
          size = 4
        ) +
        coord_fixed(1.3) +
        theme_void() +
        theme(panel.background = element_rect(fill = "#f3f2f1", color = NA))

      ggplotly(p, tooltip = "text", source = "ukmap_click")
    })

    observeEvent(event_data("plotly_click", source = "ukmap_click"), {
      click_info <- event_data("plotly_click", source = "ukmap_click")
      clicked_code <- click_info$customdata
      if (is.null(clicked_code)) return(NULL)

      vals <- regional_values()
      row <- vals[vals$area_code == clicked_code, , drop = FALSE]
      region_name <- region_dots$name[match(clicked_code, region_dots$area_code)]

      if (nrow(row) == 0 || is.na(row$value)) {
        showModal(modalDialog(
          title = paste("Regional Data:", region_name),
          p(class = "govuk-body", "No data returned for this selection."),
          easyClose = TRUE,
          footer = modalButton("Close")
        ))
      } else {
        val_txt <- format(round(row$value[1], 2), nsmall = 2)
        period_txt <- if (!is.null(row$time_period) && !is.na(row$time_period[1])) {
          paste0(" (", row$time_period[1], ")")
        } else {
          ""
        }
        showModal(modalDialog(
          title = paste("Regional Data:", region_name),
          HTML(paste0(
            "<div class='govuk-grid-row'>",
            "<div class='govuk-grid-column-full'>",
            "<p class='govuk-body'>",
            input$region_employment_group, " | ", input$region_age_group, " | ", input$region_value_type,
            period_txt,
            "</p>",
            "<h2 class='govuk-heading-l'>", val_txt, "</h2>",
            "</div></div>"
          )),
          easyClose = TRUE,
          footer = modalButton("Close")
        ))
      }
    })
    
    

    # Employment by Age 

        labour_metric_server(
      id = "age_card",
      title = "Employment",
      age_codes = employment_age_codes,
      stacked_codes = stacked_employment_codes,
      level_colour = "#1d70b8",
      rate_colour = "#00703c",
      invert = FALSE
    )
    
  })
}