# 📊 Labour Market Statistics Dashboard

## 👋 Introduction

This dashboard provides interactive visualisations and insights into key labour market indicators in the UK. It is designed to support analysts, policymakers, and stakeholders in understanding trends in employment, unemployment, vacancies, and wages.

Built using R and Shiny, the dashboard enables users to explore time series data, compare regions, and download outputs for further analysis.

## 📁 Repository Structure

```         
├── example-dashboards/       # Folder containing example Shiny apps.\
├── dashboard/                # Shiny app files\
├── tests/                    # Contains test scripts\
└── README.md                 # Project overview
```

------------------------------------------------------------------------

## 🚀 Setup

### Clone the repository

``` bash
git clone git@gitlab.data.trade.gov.uk:analysis_and_wages/strategy_security_of_work/data-science-team/labour-markets-dashboard.git
```

## 🛠️ Usage

Repo to be used for dashboard development, while users to access through hosting on DW.

## 📅 Project Management

### Authors

Jakub Borowiec ([jakub.borowiec\@businessandtrade.gov.uk](mailto:jakub.borowiec@businessandtrade.gov.uk){.email})\
Nick Avis ([Nicholas.Avis\@businessandtrade.gov.uk](mailto:Nicholas.Avis@businessandtrade.gov.uk){.email})\
Marjan Islam ([Marjan.Islam\@businessandtrade.gov.uk](mailto:Marjan.Islam@businessandtrade.gov.uk){.email})

### Project Status

[Link to wider Project Plan](https://dbis.sharepoint.com/:fl:/r/contentstorage/CSP_918bbdca-4656-4c1b-b7ff-3fdeb2aca42c/Document%20Library/LoopAppData/Plan%20on%20a%20Page.loop?d=w6471d58aee9040028bc2745f64ae3c75&csf=1&web=1&e=izC7mu&nav=cz0lMkZjb250ZW50c3RvcmFnZSUyRkNTUF85MThiYmRjYS00NjU2LTRjMWItYjdmZi0zZmRlYjJhY2E0MmMmZD1iJTIxeXIyTGtWWkdHMHkzX3pfZXNxeWtMSnRIN1Z6SS1jeE91aGEzNmJoeF9DYXFyalFIWnV3MFFaUU1ZWjZCaG5FXyZmPTAxU0RCRFVURUsyVllXSkVIT0FKQUlYUVRVTDVTSzRQRFYmYz0lMkYmYT1Mb29wQXBwJnA9JTQwZmx1aWR4JTJGbG9vcC1wYWdlLWNvbnRhaW5lciZ4PSU3QiUyMnclMjIlM0ElMjJUMFJUVUh4a1ltbHpMbk5vWVhKbGNHOXBiblF1WTI5dGZHSWhlWEl5VEd0V1drZEhNSGt6WDNwZlpYTnhlV3RNU25SSU4xWjZTUzFqZUU5MWFHRXpObUpvZUY5RFlYRnlhbEZJV25WM01GRmFVVTFaV2paQ2FHNUZYM3d3TVZORVFrUlZWRWRPUjA5T1JFZzFVMHRETlVGSlVrRlBSMGxIVmtGQ1RFMUclMjIlMkMlMjJpJTIyJTNBJTIyOTY3NmFlYTgtZWFkMC00NGM2LTk3NDktN2Q5ZjY3ZjZiOTY2JTIyJTdE)\
[Link to project Kanban board](https://planner.cloud.microsoft/webui/plan/Y_EwuI3Ze029hl7zx2BLkJYAAgCr/view/grid?tid=8fa217ec-33aa-46fb-ad96-dfe68006bb86)
