
# R/pages/page_employment.R

source("R/pages/labour_market_helpers.R")

library(ggplot2)
library(scales)
library(plotly)

# Map deps (regional map - offline)
library(dplyr)
library(maps)



#' Employment age group codes for levels and rates
#' @description Maps each age group to its ONS dataset codes
employment_age_codes <- data.frame(
  age_group = AGE_CHOICES,
  level_code = c("MGRZ", "LF2G", "YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"),
  rate_code  = c("MGSR", "LF24", "YBUA", "YBUD", "YBUG", "YBUJ", "LF2U", "LFK6"),
  stringsAsFactors = FALSE
)

#' Employment codes for stacked 
stacked_employment_codes <- data.frame(
  age_group = AGE_STACK,
  code = c("YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"),
  stringsAsFactors = FALSE
)



#' Employment Page UI
#'
#' Creates the full Employment page with multiple sections:
#' Overview, Employment by Age, Employment by Gender, Employment by Sector.
#'
#' @param id Character. The module namespace ID.
#' @return A Shiny tagList containing the complete page UI.
#' @export
employment_ui <- function(id) {
  ns <- NS(id)
  
  toc_sections <- list(
    list(
      heading = "Live Full Sample",
      items = c("Overview"           = "employment-overview",
                "Employment by Age"  = "employment-age")
    ),
    list(
      heading = "Full Sample Microdata",
      items = c("Employment by Gender" = "employment-gender",
                "Employment by Sector" = "employment-sector")
    )
  )
  
  tagList(
    side_nav(ns, sections = toc_sections, title = "On this page"),
    
    div(class = "govuk-width-container",
        tags$main(class = "govuk-main-wrapper",
                  tags$span(class = "govuk-caption-xl", "Labour Market"),
                  tags$h1(class = "govuk-heading-xl", "Employment"),
                  tags$p(class = "govuk-body-s", paste("Last updated:", Sys.Date())),
                  
                  #  Grid-
                  div(class = "govuk-grid-row",
                      div(class = "govuk-grid-column-full",
                          
                          tags$section(id = "employment-overview",
                                       div(class = "govuk-grid-row",
                                           uiOutput(ns("card_unemploy")),
                                           uiOutput(ns("card_duration")),
                                           uiOutput(ns("card_pop"))
                                       ),
                                       
                                       h2(class = "govuk-heading-m", "Trends over time"),
                                       
                                       sliderInput(ns("range"), "Year Range",
                                                   min(economics$date), max(economics$date),
                                                   value = c(as.Date("2010-01-01"), max(economics$date)),
                                                   width = "100%"),
                                       
                                       shinyWidgets::sliderTextInput(
                                         inputId = ns("lfs_date_range"),
                                         label   = "Select LFS Data Range",
                                         choices = rev(lfs_tables_full$yearquarter),
                                         selected = c("2020 Q1", lfs_tables_full$yearquarter[1]),
                                         grid = TRUE,
                                         width = "100%"
                                       ),
                                       
                                       uiOutput(ns("date_slider")),
                                       textOutput(ns("selection")),
                                       
                                       selectizeInput(
                                         inputId = ns("table_select"),
                                         label   = "Pick table from range to display:",
                                         choices = NULL,
                                         options = list(placeholder = "Type to search..."),
                                         width   = "100%"
                                       ),
                                       
                                       verbatimTextOutput(ns("picked_table")),
                                       textOutput(ns("lfs_list")),
                                       
                                       # Trend vis card
                                       mod_govuk_data_vis_card_ui(
                                         id = ns("trend_card"),
                                         title = "Employment trend",
                                         help_text = "This card hosts the visual only. Global and visual-specific filters live elsewhere.",
                                         visual_content = plotlyOutput(ns("trend"), height = "350px")
                                       ),

                                       tags$hr(class = "govuk-section-break govuk-section-break--m govuk-section-break--visible"),
                                       tags$h2(class = "govuk-heading-m", "Regional map"),
                                       tags$p(class = "govuk-body", "Interactive map of labour-market indicators by UK region and country."),

                                       div(class = "govuk-grid-row",
                                           div(class = "govuk-grid-column-one-third",
                                               selectInput(
                                                 inputId = ns("region_metric"),
                                                 label   = "Metric",
                                                 # Match the exact strings in ons.labour_market__regional_survey
                                                 choices = c("Economically active" = "Economically active 1",
                                                             "Employment" = "Employment",
                                                             "Unemployment" = "Unemployment",
                                                             "Economically inactive" = "Economically inactive"),
                                                 selected = "Employment",
                                                 width = "100%"
                                               ),
                                               selectInput(
                                                 inputId = ns("region_age"),
                                                 label   = "Age group",
                                                 choices = c("Aged 16+" = "Aged 16+",
                                                             "Aged 16-64" = "Aged 16-64"),
                                                 selected = "Aged 16-64",
                                                 width = "100%"
                                               ),
                                               selectInput(
                                                 inputId = ns("region_value_type"),
                                                 label   = "Value type",
                                                 # Data Explorer shows rate footnotes (e.g., "Rate (%)2", "Rate (%)3")
                                                 choices = c("Rate (activity/employment/inactivity)" = "Rate (%)2",
                                                             "Rate (unemployment)" = "Rate (%)3",
                                                             "Level" = "Level"),
                                                 selected = "Rate (%)2",
                                                 width = "100%"
                                               )
                                           ),
                                           div(class = "govuk-grid-column-two-thirds",
                                               mod_govuk_data_vis_card_ui(
                                                 id = ns("regional_map_card"),
                                                 title = "Regional indicator map",
                                                 help_text = "Hover for values. Colours show relative magnitude across regions.",
                                                 visual_content = plotlyOutput(ns("regional_map"), height = "450px")
                                               )
                                           )
                                       )
                          ),
                          
                          tags$section(id = "employment-age",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Age"),
                                       
                                       # Employment by Age 
                                       labour_metric_ui(
                                         id = ns("age_card"),
                                         title = "Employment",
                                         level_colour = "#1d70b8",
                                         rate_colour = "#00703c"
                                       )
                          ),
                          
                          tags$section(id = "employment-gender",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Gender"),
                                       textAreaInput(ns("notes_gender"), label = NULL, value = "",
                                                     placeholder = strrep("This is a very long placeholder. ", 200))
                          ),
                          
                          tags$section(id = "employment-sector",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Sector"),
                                       textAreaInput(ns("notes_sector"), label = NULL, value = "",
                                                     placeholder = strrep("This is a very long placeholder. ", 200))
                          )
                      )
                  )
        )
    )
  )
}




#' Employment Page Server
#'
#' Server logic for the Employment page. Handles data fetching, filtering,
#' and wiring up the various visualization modules.
#'
#' @param id Character. The module namespace ID.
#' @export
employment_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    mod_govuk_data_vis_card_server("trend_card")
    mod_govuk_data_vis_card_server("regional_map_card")
    # --- Regional map data (hardcoded snapshot from Excel, for demo/offline use) ---
# Headline estimates for Sep–Nov 2025 (published 20 Jan 2026), units:
# - Levels: thousands (seasonally adjusted)
# - Rates: percent
snapshot <- tibble::tribble(
  ~area_code,  ~area_name,
  ~ea_level_16p, ~ea_rate_1664,
  ~emp_level_16p, ~emp_rate_1664,
  ~unemp_level_16p, ~unemp_rate_16p,
  ~inactive_level_1664, ~inactive_rate_1664,
  "K02000001", "United Kingdom",        36143, 79.2, 34303, 75.1, 1840, 5.1, 9021, 20.8,
  "K03000001", "Great Britain",         35227, 79.4, 33407, 75.2, 1821, 5.2, 8707, 20.6,
  "E92000001", "England",               30895, 79.7, 29261, 75.4, 1634, 5.3, 7468, 20.3,
  "E12000001", "North East",             1318, 74.0,  1236, 69.2,   82, 6.2,  442, 26.0,
  "E12000002", "North West",             3934, 77.7,  3737, 73.8,  197, 5.0, 1075, 22.3,
  "E12000003", "Yorkshire and The Humber",2883,77.5,  2719, 73.0,  164, 5.7,  799, 22.5,
  "E12000004", "East Midlands",          2635, 79.9,  2478, 75.0,  157, 6.0,  632, 20.1,
  "E12000005", "West Midlands",          3136, 78.5,  2953, 73.7,  184, 5.9,  820, 21.5,
  "E12000006", "East",                   3511, 82.2,  3359, 78.5,  153, 4.3,  717, 17.8,
  "E12000007", "London",                 5232, 79.7,  4856, 74.0,  376, 7.2, 1274, 20.3,
  "E12000008", "South East",             5154, 82.2,  4942, 78.8,  212, 4.1, 1052, 17.8,
  "E12000009", "South West",             3092, 81.6,  2982, 78.7,  110, 3.6,  656, 18.4,
  "W92000004", "Wales",                  1550, 75.5,  1466, 71.3,   84, 5.4,  479, 24.5,
  "S92000003", "Scotland",               2783, 77.7,  2680, 74.7,  103, 3.7,  760, 22.3,
  "N92000002", "Northern Ireland",        916, 73.6,   896, 72.0,   19, 2.1,  314, 26.4
)

# Points for regions/countries (approximate centroids). We intentionally
# omit UK/GB/England points from the map to avoid clutter.
dots <- tibble::tribble(
  ~area_code,  ~area_name,                   ~lat,    ~lng,
  "E12000001", "North East",                 54.9783, -1.6178,  # Newcastle
  "E12000002", "North West",                 53.4808, -2.2426,  # Manchester
  "E12000003", "Yorkshire and The Humber",   53.8008, -1.5491,  # Leeds
  "E12000004", "East Midlands",              52.9548, -1.1581,  # Nottingham
  "E12000005", "West Midlands",              52.4862, -1.8904,  # Birmingham
  "E12000006", "East",                       52.2053,  0.1218,  # Cambridge
  "E12000007", "London",                     51.5074, -0.1278,
  "E12000008", "South East",                 51.4543, -0.9781,  # Reading-ish
  "E12000009", "South West",                 51.4545, -2.5879,  # Bristol
  "W92000004", "Wales",                      51.4816, -3.1791,  # Cardiff
  "S92000003", "Scotland",                   55.9533, -3.1883,  # Edinburgh
  "N92000002", "Northern Ireland",           54.5973, -5.9301   # Belfast
)

# Selector -> which snapshot column to use
selected_values <- reactive({
  req(input$region_metric, input$region_age, input$region_value_type)

  # Map the UI selections onto the snapshot columns
  key <- paste(input$region_metric, input$region_age, input$region_value_type, sep = " | ")

  col <- dplyr::case_when(
    key == "Economically active 1 | Aged 16+ | Level"               ~ "ea_level_16p",
    key == "Economically active 1 | Aged 16-64 | Rate (%)2"         ~ "ea_rate_1664",
    key == "Employment | Aged 16+ | Level"                          ~ "emp_level_16p",
    key == "Employment | Aged 16-64 | Rate (%)2"                    ~ "emp_rate_1664",
    key == "Unemployment | Aged 16+ | Level"                        ~ "unemp_level_16p",
    key == "Unemployment | Aged 16+ | Rate (%)3"                    ~ "unemp_rate_16p",
    key == "Economically inactive | Aged 16-64 | Level"             ~ "inactive_level_1664",
    key == "Economically inactive | Aged 16-64 | Rate (%)2"         ~ "inactive_rate_1664",
    TRUE                                                            ~ NA_character_
  )

  req(!is.na(col))

  snapshot |>
    dplyr::select(area_code, area_name, value = dplyr::all_of(col)) |>
    dplyr::mutate(value = as.numeric(value))
})

# Render the map using ggplot + plotly (works offline; no leaflet tiles)
output$regional_map <- renderPlotly({
  vals <- selected_values()
  req(nrow(vals) > 0)

  # UK land mass (offline, from maps package)
  uk_shape <- map_data("world", region = "UK")

  # Join values onto the dots
  plot_df <- dots |>
    dplyr::left_join(vals, by = c("area_code", "area_name"))

  # Format values for tooltip
  is_rate <- grepl("^Rate", input$region_value_type %||% "")
  plot_df <- plot_df |>
    dplyr::mutate(
      value_fmt = dplyr::if_else(
        is.na(value),
        "No data",
        dplyr::if_else(is_rate, paste0(sprintf("%.1f", value), "%"), scales::comma(value))
      ),
      tooltip = paste0(area_name, "<br>", value_fmt)
    )

  p <- ggplot() +
    geom_polygon(
      data = uk_shape,
      aes(x = long, y = lat, group = group),
      fill = "#d2d2d2",
      color = "white"
    ) +
    geom_point(
      data = plot_df,
      aes(x = lng, y = lat, text = tooltip, customdata = area_code, size = value),
      color = "#1d70b8",
      alpha = 0.9
    ) +
    coord_fixed(1.3) +
    theme_void() +
    theme(panel.background = element_rect(fill = "#f3f2f1", color = NA))

  ggplotly(p, tooltip = "text", source = "ukmap_click") |>
    layout(showlegend = FALSE)
})

# Click -> show a nicer modal with all headline stats for the region
observeEvent(event_data("plotly_click", source = "ukmap_click"), {
  click_info <- event_data("plotly_click", source = "ukmap_click")
  code <- click_info$customdata
  req(!is.null(code))

  row <- snapshot |>
    dplyr::filter(area_code == code) |>
    dplyr::slice(1)

  req(nrow(row) == 1)

  make_card <- function(title, big, small) {
    paste0(
      "<div style='flex:1; min-width:170px; padding:12px; background:#f3f2f1; border-top:4px solid #1d70b8; border-radius:6px;'>",
      "<div style='font-size:14px; color:#505a5f; margin-bottom:6px;'>", title, "</div>",
      "<div style='font-size:26px; font-weight:700; color:#0b0c0c; line-height:1.1;'>", big, "</div>",
      "<div style='font-size:13px; color:#505a5f; margin-top:4px;'>", small, "</div>",
      "</div>"
    )
  }

  html <- paste0(
    "<div style='display:flex; flex-wrap:wrap; gap:12px;'>",
    make_card("Economically active", scales::comma(row$ea_level_16p), paste0(row$ea_rate_1664, "% (aged 16–64)")),
    make_card("Employment",          scales::comma(row$emp_level_16p), paste0(row$emp_rate_1664, "% (aged 16–64)")),
    make_card("Unemployment",        scales::comma(row$unemp_level_16p), paste0(row$unemp_rate_16p, "% (aged 16+)")),
    make_card("Economically inactive", scales::comma(row$inactive_level_1664), paste0(row$inactive_rate_1664, "% (aged 16–64)")),
    "</div>"
  )

  showModal(modalDialog(
    title = row$area_name,
    htmltools::HTML(html),
    easyClose = TRUE,
    footer = modalButton("Close"),
    size = "l"
  ))
})
    
    dat <- reactive({
      economics[economics$date >= input$range[1] & economics$date <= input$range[2], ]
    })
    
    output$selection <- renderText({
      paste("Selected range:",
            input$lfs_date_range[1], "to",
            input$lfs_date_range[2])
    })
    
    lfs_selected_tables <- reactive({
      get_lfs_table_from_range(input$lfs_date_range[1], input$lfs_date_range[2])
    })
    
    output$lfs_list <- renderText({
      paste("Selected LFS tables: ",
            paste(lfs_selected_tables(), collapse = ", "))
    })
    
    observeEvent(lfs_selected_tables(), {
      choices <- lfs_selected_tables()
      req(length(choices) > 0)
      
      current <- isolate(input$table_select)
      selected <- if (!is.null(current) && current %in% choices) current else choices[1]
      
      updateSelectizeInput(
        session  = session,
        inputId  = "table_select",
        choices  = choices,
        selected = selected,
        server   = TRUE
      )
    }, ignoreInit = FALSE)
    
    output$picked_table <- renderPrint({
      input$table_select
    })
    
    
    #  Stats Cards
    
    output$card_unemploy <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$unemploy, 1); prev <- tail(d$unemploy, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("unemploy"),
        title    = "Total Unemployed",
        headline = govuk_format_number(curr),
        delta    = govuk_format_number(delta),
        period   = "vs last month",
        good_if_increase = FALSE
      )
    })
    
    output$card_duration <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$uempmed, 1); prev <- tail(d$uempmed, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("duration"),
        title    = "Duration (Weeks)",
        headline = govuk_format_number(curr),
        delta    = scales::comma(round(delta, 1)),
        period   = "vs last month",
        good_if_increase = FALSE
      )
    })
    
    output$card_pop <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$pop, 1); prev <- tail(d$pop, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("population"),
        title    = "Population",
        headline = govuk_format_number(curr),
        delta    = scales::comma(round(delta, 1)),
        period   = "vs last month",
        good_if_increase = TRUE
      )
    })
    
    # Trend plot
    output$trend <- renderPlotly({
      ggplotly(
        ggplot(dat(), aes(date, unemploy)) +
          geom_area(fill = "#cf102d", alpha = 0.2) +
          geom_line(col = "#cf102d", size = 1) +
          theme_minimal() +
          labs(x = NULL, y = "Unemployed (000s)")
      )
    })
    
    

    # Employment by Age 

        labour_metric_server(
      id = "age_card",
      title = "Employment",
      age_codes = employment_age_codes,
      stacked_codes = stacked_employment_codes,
      level_colour = "#1d70b8",
      rate_colour = "#00703c",
      invert = FALSE
    )
    
  })
}