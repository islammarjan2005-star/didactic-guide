
# R/pages/page_employment.R

source("R/pages/labour_market_helpers.R")

library(ggplot2)
library(scales)
library(plotly)
library(leaflet)


#' Employment age group codes for levels and rates
#' @description Maps each age group to its ONS dataset codes
employment_age_codes <- data.frame(
  age_group = AGE_CHOICES,
  level_code = c("MGRZ", "LF2G", "YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"),
  rate_code  = c("MGSR", "LF24", "YBUA", "YBUD", "YBUG", "YBUJ", "LF2U", "LFK6"),
  stringsAsFactors = FALSE
)

#' Employment codes for stacked 
stacked_employment_codes <- data.frame(
  age_group = AGE_STACK,
  code = c("YBTO", "YBTR", "YBTU", "YBTX", "LF26", "LFK4"),
  stringsAsFactors = FALSE
)



#' Employment Page UI
#'
#' Creates the full Employment page with multiple sections:
#' Overview, Employment by Age, Employment by Gender, Employment by Sector.
#'
#' @param id Character. The module namespace ID.
#' @return A Shiny tagList containing the complete page UI.
#' @export
employment_ui <- function(id) {
  ns <- NS(id)
  
  toc_sections <- list(
    list(
      heading = "Live Full Sample",
      items = c("Overview"           = "employment-overview",
                "Employment by Age"  = "employment-age")
    ),
    list(
      heading = "Full Sample Microdata",
      items = c("Employment by Gender" = "employment-gender",
                "Employment by Sector" = "employment-sector")
    )
  )
  
  tagList(
    side_nav(ns, sections = toc_sections, title = "On this page"),
    
    div(class = "govuk-width-container",
        tags$main(class = "govuk-main-wrapper",
                  tags$span(class = "govuk-caption-xl", "Labour Market"),
                  tags$h1(class = "govuk-heading-xl", "Employment"),
                  tags$p(class = "govuk-body-s", paste("Last updated:", Sys.Date())),
                  
                  #  Grid-
                  div(class = "govuk-grid-row",
                      div(class = "govuk-grid-column-full",
                          
                          tags$section(id = "employment-overview",
                                       div(class = "govuk-grid-row",
                                           uiOutput(ns("card_unemploy")),
                                           uiOutput(ns("card_duration")),
                                           uiOutput(ns("card_pop"))
                                       ),
                                       
                                       h2(class = "govuk-heading-m", "Trends over time"),
                                       
                                       sliderInput(ns("range"), "Year Range",
                                                   min(economics$date), max(economics$date),
                                                   value = c(as.Date("2010-01-01"), max(economics$date)),
                                                   width = "100%"),
                                       
                                       shinyWidgets::sliderTextInput(
                                         inputId = ns("lfs_date_range"),
                                         label   = "Select LFS Data Range",
                                         choices = rev(lfs_tables_full$yearquarter),
                                         selected = c("2020 Q1", lfs_tables_full$yearquarter[1]),
                                         grid = TRUE,
                                         width = "100%"
                                       ),
                                       
                                       uiOutput(ns("date_slider")),
                                       textOutput(ns("selection")),
                                       
                                       selectizeInput(
                                         inputId = ns("table_select"),
                                         label   = "Pick table from range to display:",
                                         choices = NULL,
                                         options = list(placeholder = "Type to search..."),
                                         width   = "100%"
                                       ),
                                       
                                       verbatimTextOutput(ns("picked_table")),
                                       textOutput(ns("lfs_list")),
                                       
                                       # Trend vis card
                                       mod_govuk_data_vis_card_ui(
                                         id = ns("trend_card"),
                                         title = "Employment trend",
                                         help_text = "This card hosts the visual only. Global and visual-specific filters live elsewhere.",
                                         visual_content = plotlyOutput(ns("trend"), height = "350px")
                                       )
,
tags$hr(class = "govuk-section-break govuk-section-break--l govuk-section-break--visible"),
h2(class = "govuk-heading-m", "Regional breakdown (interactive map)"),
p(class = "govuk-body", "Select an indicator and click a region to view the latest value."),

div(class = "govuk-grid-row",
    div(class = "govuk-grid-column-one-third",
        selectInput(ns("reg_employment_group"), "Group",
                    choices = c("Economically active", "Employment", "Unemployment", "Economically inactive"),
                    selected = "Employment", width = "100%")
    ),
    div(class = "govuk-grid-column-one-third",
        selectInput(ns("reg_age_group"), "Age group",
                    choices = c("Aged 16 and over", "Aged 16 to 64"),
                    selected = "Aged 16 and over", width = "100%")
    ),
    div(class = "govuk-grid-column-one-third",
        selectInput(ns("reg_value_type"), "Measure",
                    choices = c("Level", "Rate (%)2", "Rate (%)3"),
                    selected = "Rate (%)2", width = "100%")
    )
),

div(style = "border: 2px solid #b1b4b6;",
    leafletOutput(ns("regional_map"), height = "560px")
)
                          ),
                          
                          tags$section(id = "employment-age",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Age"),
                                       
                                       # Employment by Age 
                                       labour_metric_ui(
                                         id = ns("age_card"),
                                         title = "Employment",
                                         level_colour = "#1d70b8",
                                         rate_colour = "#00703c"
                                       )
                          ),
                          
                          tags$section(id = "employment-gender",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Gender"),
                                       textAreaInput(ns("notes_gender"), label = NULL, value = "",
                                                     placeholder = strrep("This is a very long placeholder. ", 200))
                          ),
                          
                          tags$section(id = "employment-sector",
                                       tags$h1(class = "govuk-heading-xl", "Employment by Sector"),
                                       textAreaInput(ns("notes_sector"), label = NULL, value = "",
                                                     placeholder = strrep("This is a very long placeholder. ", 200))
                          )
                      )
                  )
        )
    )
  )
}




#' Employment Page Server
#'
#' Server logic for the Employment page. Handles data fetching, filtering,
#' and wiring up the various visualization modules.
#'
#' @param id Character. The module namespace ID.
#' @export
employment_server <- function(id) {
  moduleServer(id, function(input, output, session) {
    
    mod_govuk_data_vis_card_server("trend_card")
    
    dat <- reactive({
      economics[economics$date >= input$range[1] & economics$date <= input$range[2], ]
    })
    
    output$selection <- renderText({
      paste("Selected range:",
            input$lfs_date_range[1], "to",
            input$lfs_date_range[2])
    })
    
    lfs_selected_tables <- reactive({
      get_lfs_table_from_range(input$lfs_date_range[1], input$lfs_date_range[2])
    })
    
    output$lfs_list <- renderText({
      paste("Selected LFS tables: ",
            paste(lfs_selected_tables(), collapse = ", "))
    })
    
    observeEvent(lfs_selected_tables(), {
      choices <- lfs_selected_tables()
      req(length(choices) > 0)
      
      current <- isolate(input$table_select)
      selected <- if (!is.null(current) && current %in% choices) current else choices[1]
      
      updateSelectizeInput(
        session  = session,
        inputId  = "table_select",
        choices  = choices,
        selected = selected,
        server   = TRUE
      )
    }, ignoreInit = FALSE)
    
    output$picked_table <- renderPrint({
      input$table_select
    })
    
    
    #  Stats Cards
    
    output$card_unemploy <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$unemploy, 1); prev <- tail(d$unemploy, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("unemploy"),
        title    = "Total Unemployed",
        headline = govuk_format_number(curr),
        delta    = govuk_format_number(delta),
        period   = "vs last month",
        good_if_increase = FALSE
      )
    })
    
    output$card_duration <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$uempmed, 1); prev <- tail(d$uempmed, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("duration"),
        title    = "Duration (Weeks)",
        headline = govuk_format_number(curr),
        delta    = scales::comma(round(delta, 1)),
        period   = "vs last month",
        good_if_increase = FALSE
      )
    })
    
    output$card_pop <- renderUI({
      d <- dat(); req(nrow(d) >= 2)
      curr <- tail(d$pop, 1); prev <- tail(d$pop, 2)[1]
      delta <- curr - prev
      
      govuk_stats_card(
        id       = session$ns("population"),
        title    = "Population",
        headline = govuk_format_number(curr),
        delta    = scales::comma(round(delta, 1)),
        period   = "vs last month",
        good_if_increase = TRUE
      )
    })
    
    # Trend plot
    output$trend <- renderPlotly({
      ggplotly(
        ggplot(dat(), aes(date, unemploy)) +
          geom_area(fill = "#cf102d", alpha = 0.2) +
          geom_line(col = "#cf102d", size = 1) +
          theme_minimal() +
          labs(x = NULL, y = "Unemployed (000s)")
      )


# --------------------------------------------------------------------------
# Regional Leaflet map
# NOTE: Basemap tiles are fetched by the viewer's browser. So this works when
# the Shiny app is opened in a normal browser with internet access, even if
# the RStudio host is policy-offline.
# --------------------------------------------------------------------------

region_lookup <- data.frame(
  area_code = c("E12000001","E12000002","E12000003","E12000004","E12000005","E12000006","E12000007","E12000008","E12000009",
                "W92000004","S92000003","N92000002"),
  area_name = c("North East","North West","Yorkshire and The Humber","East Midlands","West Midlands","East of England","London","South East","South West",
                "Wales","Scotland","Northern Ireland"),
  lat = c(54.9783,53.7632,53.8008,52.9548,52.4862,52.2405,51.5074,51.2710,50.7184,
          52.1307,56.4907,54.7877),
  lng = c(-1.6178,-2.7044,-1.5486,-1.1581,-1.8904,0.7133,-0.1278,-0.9590,-3.5339,
          -3.7837,-4.2026,-6.4923),
  stringsAsFactors = FALSE
)

conn_reg <- dbConnect(RPostgres::Postgres())
onStop(function() dbDisconnect(conn_reg))

regional_values <- reactive({
  req(input$reg_employment_group, input$reg_age_group, input$reg_value_type)

  fields <- tryCatch(DBI::dbListFields(conn_reg, DBI::Id(schema = "ons", table = "labour_market__regional_survey")),
                     error = function(e) character(0))
  has_time <- "time_period" %in% fields

  base_where <- sprintf(
    "employment_group = '%s' AND age_group = '%s' AND value_type = '%s' AND area_code IN (%s)",
    gsub("'", "''", input$reg_employment_group),
    gsub("'", "''", input$reg_age_group),
    gsub("'", "''", input$reg_value_type),
    paste0("'", region_lookup$area_code, "'", collapse = ",")
  )

  if (has_time) {
    q <- sprintf('
      WITH latest AS (
        SELECT MAX(time_period) AS tp
        FROM "ons"."labour_market__regional_survey"
        WHERE %s
      )
      SELECT r.time_period, r.employment_group, r.age_group, r.value_type, r.area_code, r.value
      FROM "ons"."labour_market__regional_survey" r
      JOIN latest l ON r.time_period = l.tp
      WHERE %s
    ', base_where, base_where)
  } else {
    q <- sprintf('
      SELECT employment_group, age_group, value_type, area_code, value
      FROM "ons"."labour_market__regional_survey"
      WHERE %s
    ', base_where)
  }

  df <- DBI::dbGetQuery(conn_reg, q)
  if (nrow(df) == 0) return(df)
  df$value <- suppressWarnings(as.numeric(df$value))
  merge(df, region_lookup, by = "area_code", all.x = TRUE)
})

output$regional_map <- renderLeaflet({
  leaflet(options = leafletOptions(zoomControl = TRUE)) %>%
    addProviderTiles(providers$CartoDB.Positron, options = providerTileOptions(noWrap = TRUE)) %>%
    setView(lng = -2.5, lat = 54.2, zoom = 5)
})

observe({
  df <- regional_values()
  req(nrow(df) > 0)

  pal <- colorNumeric("YlOrRd", domain = df$value, na.color = "#b1b4b6")
  popup <- sprintf(
    "<strong>%s</strong><br/>%s · %s · %s<br/><strong>%s</strong>",
    df$area_name, df$employment_group, df$age_group, df$value_type,
    ifelse(is.na(df$value), "NA", format(df$value, big.mark = ","))
  )

  leafletProxy(session$ns("regional_map"), session = session) %>%
    clearMarkers() %>%
    clearControls() %>%
    addCircleMarkers(
      lng = df$lng, lat = df$lat,
      radius = 8, stroke = TRUE, weight = 1,
      color = "#0b0c0c", fillColor = pal(df$value), fillOpacity = 0.9,
      label = lapply(df$area_name, htmltools::HTML),
      popup = lapply(popup, htmltools::HTML)
    ) %>%
    addLegend(position = "bottomright",
              pal = pal, values = df$value,
              title = htmltools::HTML(input$reg_value_type),
              opacity = 0.9)
})

    })
    
    

    # Employment by Age 

        labour_metric_server(
      id = "age_card",
      title = "Employment",
      age_codes = employment_age_codes,
      stacked_codes = stacked_employment_codes,
      level_colour = "#1d70b8",
      rate_colour = "#00703c",
      invert = FALSE
    )
    
  })
}